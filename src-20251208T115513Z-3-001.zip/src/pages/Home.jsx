import React from "react";

function Home() {

    return (
        <div>
            <h1>歡迎來到購物車範例</h1>
            <p>探索我們的商品, 並將喜愛的商品加入到購物車</p>
        </div>
    )

}

export default Home;